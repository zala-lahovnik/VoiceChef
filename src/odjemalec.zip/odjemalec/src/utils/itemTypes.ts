export type Item = {
  _id: string;
  item: string;
  quantity: number;
  unit: string;
  store: string;
};